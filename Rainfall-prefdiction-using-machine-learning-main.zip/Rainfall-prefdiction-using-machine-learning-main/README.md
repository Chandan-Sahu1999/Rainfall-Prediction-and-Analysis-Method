# Rainfall-prefdiction-using-machine-learning
This is a rainfall prediction project using pandas, numpy and machine learning algorithms to find the accuracy
